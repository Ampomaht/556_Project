Alpha version.

Note that the input must be in the format as in.txt included in the zip here
The coordinates of all pins must be seperated by a space charactar (eg. ' ') 
for the program to run properly. If there's any problem in running the program,
please contact me by email.
Tiachunpun@wisc.edu

If the program reads the input correctly, it should output the routing solution to
out.txt as included 

You can try to run the in.txt (from project's sample input) and see the output as attached.

Thank you.